from world2.world import *

import matplotlib.pyplot as plt
import numpy as np

my_world=created_world('world1.dat')
print_world()
